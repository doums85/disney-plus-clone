# Disney Plus Clone Readme

## <a href="https://disney-clone-d1e27.firebaseapp.com" target="_blank">LIVE DEMO</a>

### 🔴 Watch full tutorial <a href='https://www.youtube.com/watch?v=R_OERlafbmw'>HERE</a>

## Description
This is the ReactJS Disney Plus Clone, the perfect project to put on your portfolio by Clever Programmer.

## Build it today!

#### PREREQUISITES:
- Sign up for a Firebase account <a href='https://firebase.google.com'>HERE</a>
- Install Node JS in your computer <a href='https://nodejs.org/en/'>HERE</a>
- Download all the images and videos <a href='https://drive.google.com/drive/folders/13SvUkXPh7ZC1FRtp62VKFi572elZyxi8?usp=sharing'>HERE</a>
